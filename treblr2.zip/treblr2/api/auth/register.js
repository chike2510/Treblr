import { connectDB } from '../../lib/db.js';
import User from '../../lib/models/User.js';
import jwt from 'jsonwebtoken';
import { cors, handleOptions } from '../../lib/cors.js';

export default async function handler(req, res) {
  cors(res);
  if (handleOptions(req, res)) return;
  if (req.method !== 'POST') return res.status(405).end();

  await connectDB();

  try {
    const { username, email, password, artistName, genre } = req.body;
    if (!username || !email || !password || !artistName)
      return res.status(400).json({ error: 'All fields required' });

    const exists = await User.findOne({ $or: [{ email }, { username }] });
    if (exists) return res.status(400).json({ error: 'Username or email already taken' });

    const colors = ['#e74c3c','#e67e22','#2ecc71','#3498db','#9b59b6','#1abc9c','#e91e63','#ff9800'];
    const avatarColor = colors[Math.floor(Math.random() * colors.length)];

    const user = new User({ username, email, password, artistName, genre: genre||'Pop', avatarColor });
    await user.save();

    // Auto-seed NPCs on first user ever
    const { Artist } = await import('../../lib/models/models.js');
    const npcCount = await Artist.countDocuments({ isNPC: true });
    if (npcCount < 50) {
      const { seedNPCs } = await import('../../lib/services.js');
      seedNPCs(300).catch(console.error); // async, don't block
    }

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET || 'treblr_dev_secret', { expiresIn: '30d' });
    res.status(201).json({ token, user: safeUser(user) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

function safeUser(u) {
  const o = u.toObject();
  delete o.password;
  return o;
}
