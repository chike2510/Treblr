export { LeaderboardPanel as default } from './allPanels.jsx';
